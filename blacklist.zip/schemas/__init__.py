from .blacklist_schema import BlacklistSchema
