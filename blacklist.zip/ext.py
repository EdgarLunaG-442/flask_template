from flask_marshmallow import Marshmallow
from flask_migrate import Migrate

marshmallow = Marshmallow()
migrate = Migrate()
